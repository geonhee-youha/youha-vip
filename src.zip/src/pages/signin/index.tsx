import { Stack } from "@mui/material";
import { useRouter } from "next/router";
import { ChangeEvent, useState } from "react";
import Button from "../../components/atoms/Button";
import Checkbox from "../../components/atoms/Checkbox";
import TextField from "../../components/atoms/TextField";
import Typography from "../../components/atoms/Typography";
import { inputDefault, InputProps } from "../../contants/values";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";
import { youhaBlue } from "../../themes/youhaBlue";

export default function Page() {
  const router = useRouter();
  const [checked, setChecked] = useState<boolean>(false);
  const [email, setEmail] = useState<InputProps>(inputDefault);
  const [password, setPassword] = useState<InputProps>(inputDefault);
  const handleChangeEmail = (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setEmail((prev) => {
      return {
        ...prev,
        value: value,
      };
    });
  };
  const handleChangePassword = (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setPassword((prev) => {
      return {
        ...prev,
        value: value,
      };
    });
  };
  const handleResetEmail = () => {
    setEmail(inputDefault);
  };
  const handleResetPassword = () => {
    setPassword(inputDefault);
  };
  const handleKeyPress = () => {
    handleClickSignin();
  };
  const handleClickChecked = () => {
    setChecked((prev) => !prev);
  };
  const handleClickPasswordReset = () => {
    router.push(`/password_reset`);
  };
  const handleClickSignin = () => {
    router.push(`/campaigns`);
  };
  return (
    <Stack
      spacing={4}
      justifyContent="center"
      alignItems="center"
      sx={{
        width: "100%",
        height: "100vh",
        minHeight: 800,
        p: theme.spacing(3, 3, 12, 3),
        backgroundColor: "#ffffff",
      }}
    >
      <Stack
        spacing={4}
        sx={{
          width: "100%",
          maxWidth: 320,
          m: theme.spacing(0, "auto"),
        }}
      >
        <Stack spacing={3}>
          <Stack spacing={1}>
            <Typography variant="heading-1">로그인하기</Typography>
            <Typography variant="body-1" color={newGrey[650]}>
              반가워요! 유하에 로그인 후 광고를 관리하세요.
            </Typography>
          </Stack>
        </Stack>
        <Stack spacing={3}>
          <Stack spacing={2}>
            <TextField
              label="이메일"
              placeholder="example@example.com"
              value={email.value}
              onChange={handleChangeEmail}
              onKeyPress={handleKeyPress}
              onReset={handleResetEmail}
            />
            <TextField
              type="password"
              label="비밀번호"
              placeholder=""
              value={password.value}
              onChange={handleChangePassword}
              onKeyPress={handleKeyPress}
              onReset={handleResetPassword}
            />
          </Stack>
          <Stack direction="row" justifyContent="space-between">
            <Checkbox checked={checked} onClick={handleClickChecked}>
              로그인 유지
            </Checkbox>
            <Typography
              variant="title-3"
              color={youhaBlue[700]}
              onClick={handleClickPasswordReset}
            >
              비밀번호를 잊으셨나요?
            </Typography>
          </Stack>
          <Stack spacing={2}>
            <Button onClick={handleClickSignin}>로그인</Button>
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
}
