import { Box, Stack } from "@mui/material";
import Typography from "../../components/atoms/Typography";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";

export default function Page() {
  return (
    <Stack
      spacing={4}
      sx={{
        p: theme.spacing(4, 0, 4, 39),
      }}
    >
      <Stack
        spacing={3}
        sx={{
          p: theme.spacing(0, 4),
        }}
      >
        <Stack spacing={0.5}>
          <Typography variant="display-sm-bold">로그인하기</Typography>
          <Typography color={newGrey[650]}>
            반가워요! 유하에 로그인 후 광고를 관리하세요.
          </Typography>
        </Stack>
      </Stack>
    </Stack>
  );
}
