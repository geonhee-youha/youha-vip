import { IconName } from "@fortawesome/fontawesome-svg-core";
import { alpha, Button as Btn, Stack } from "@mui/material";
import {
  buttonFontStyles,
  buttonIconSizes,
  ButtonSizeProps,
  buttonSizes,
  ButtonVariantProps,
} from "../../contants/styles";
import Icon from "./Icon";
import Typography from "./Typography";

export default function Button({
  fullWidth,
  variant,
  children,
  size = "md",
  theme,
  onClick,
  iconName,
}: {
  fullWidth?: boolean | undefined;
  variant?: ButtonVariantProps;
  children?: React.ReactNode;
  size?: ButtonSizeProps;
  theme?:
    | "inherit"
    | "primary"
    | "secondary"
    | "success"
    | "error"
    | "info"
    | "warning"
    | undefined;
  onClick?: () => void;
  iconName?: IconName;
}) {
  return (
    <Btn
      fullWidth={fullWidth}
      variant={variant}
      color={theme}
      disableElevation
      sx={{
        borderRadius: 0.5,
        ...buttonSizes[size],
      }}
      onClick={onClick}
    >
      <Stack
        spacing={0.5}
        direction="row"
        justifyContent="center"
        alignItems="center"
        sx={{
          flex: 1,
        }}
      >
        {iconName && (
          <Icon
            prefix="fas"
            size={buttonIconSizes[size].fontSize + 4}
            name={iconName}
            sx={{
              color: `inherit !important`,
            }}
          />
        )}
        <Typography
          sx={{
            ...buttonFontStyles[size],
            color: 'inherit'
          }}
        >
          {children}
        </Typography>
      </Stack>
    </Btn>
  );
}
