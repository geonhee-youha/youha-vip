import { alpha, Box, Stack } from "@mui/material";
import { grey } from "@mui/material/colors";
import { useRef } from "react";
import { newGrey } from "../../themes/colors";
import { youhaBlue } from "../../themes/youhaBlue";
import Icon from "./Icon";
import IconButton from "./IconButton";
import Typography from "./Typography";

export default function Checkbox({
  checked,
  children,
  onClick,
}: {
  checked?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
}) {
  const ref = useRef<any>(null);
  const borderColor = checked ? youhaBlue[500] : newGrey[300];
  const backgroundColor = checked ? youhaBlue[500] : "#ffffff";
  const hoverBackgroundColor = checked ? youhaBlue[700] : newGrey[150];
  const handleClick = () => {
    ref.current.focus();
    if (onClick) onClick();
  };
  return (
    <Stack direction="row" alignItems="center" spacing={1}>
      <IconButton
        buttonRef={ref}
        sx={{
          borderRadius: 0.25,
          width: 16,
          height: 16,
          backgroundColor: backgroundColor,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          boxShadow: `0px 0px 0px 1px ${borderColor} inset`,
          ":hover": {
            backgroundColor: `${hoverBackgroundColor} !important`,
          },
          transition: `all 0.35s ease`,
        }}
        onClick={handleClick}
      >
        {checked && (
          <Icon prefix="fas" name="check" size={14} color="#ffffff" />
        )}
      </IconButton>
      <Typography variant="body-1" onClick={handleClick} tabIndex={-1}>
        {children}
      </Typography>
    </Stack>
  );
}
