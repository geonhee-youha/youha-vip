import { ButtonBase } from "@mui/material";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";

export default function Paper({ children }: { children?: React.ReactNode }) {
  return (
    <ButtonBase
      sx={{
        borderRadius: 0.5,
        p: theme.spacing(1.5, 2),
        boxShadow: `0px 0px 0px 1px ${newGrey[200]} inset`,
        ":hover": {
          transform: `translateY(-4px)`,
          backgroundColor: "#ffffff !important",
          boxShadow: `0px 0px 0px 0px ${newGrey[200]} inset, 0px 4px 12px 0px rgba(0, 0, 0, 0.07)`,
        },
      }}
    >
      {children}
    </ButtonBase>
  );
}
