import { Typography as Typo, SxProps } from "@mui/material";
import { fontStyles, TypographyVariantProps } from "../../contants/styles";
import { newGrey } from "../../themes/colors";

type TypoProps = {
  variant?: TypographyVariantProps;
  textAlign?: "center" | "right" | undefined;
  lines?: number;
  children?: React.ReactNode;
  sx?: SxProps;
  className?: any;
  color?: string;
  onClick?: () => void;
  tabIndex?: number;
  component?: any;
};

export default function Typography({
  variant = "body-1",
  textAlign,
  lines,
  children,
  sx,
  className,
  color = newGrey[900],
  onClick,
  tabIndex,
  component = "div",
}: TypoProps) {
  const clickable = typeof onClick !== "undefined";
  function InnerTypo() {
    return (
      <Typo
        tabIndex={tabIndex ? tabIndex : typeof onClick !== "undefined" ? 0 : -1}
        component={
          typeof onClick !== "undefined" ? "button" : component ?? "div"
        }
        sx={
          typeof lines === "number"
            ? {
                ...fontStyles[variant],
                display: "-webkit-box",
                overflow: "hidden",
                WebkitBoxOrient: "vertical",
                lineClamp: lines,
                WebkitLineClamp: lines,
                whiteSpace: "pre-line",
                wordBreak: "break-all",
                textAlign: textAlign,
                color: color,
                cursor: clickable ? "pointer" : "initial",
                transition: `all 0.35s ease`,
                ...sx,
              }
            : {
                ...fontStyles[variant],
                wordBreak: "keep-all",
                textAlign: textAlign,
                color: color,
                cursor: clickable ? "pointer" : "initial",
                transition: `all 0.35s ease`,
                ...sx,
              }
        }
        className={className}
        onClick={onClick}
      >
        {children}
      </Typo>
    );
  }
  return <InnerTypo />;
}
