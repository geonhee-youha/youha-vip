import { Box, Stack } from "@mui/material";
import { useSetRecoilState } from "recoil";
import { mainDrawerOpenState } from "../../recoils";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";
import Icon from "../atoms/Icon";
import IconButton from "../atoms/IconButton";

export default function MainHeader() {
  const setMainDrawerOpenState = useSetRecoilState(mainDrawerOpenState);
  const handleClickBars = () => {
    setMainDrawerOpenState((prev) => !prev);
  };
  return (
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
      spacing={1}
      sx={{
        position: "fixed",
        top: 0,
        left: 0,
        width: 320,
        backgroundColor: "#ffffff",
        zIndex: 100,
        borderRight: `1px solid ${newGrey[200]}`,
        p: theme.spacing(1, 1.5, 1, 2),
        transition: `all 0.35s ease`,
        "& img": {
          width: "auto",
          height: `24px`,
        },
        "@media(max-width: 578px)": {
          width: "100%",
          borderRight: "none",
        },
      }}
    >
      <Box sx={{ flex: 1 }}>
        <img src="/images/logo/youha_logo-black.png" />
      </Box>
      <Stack direction="row" spacing={1}>
        <IconButton mobile>
          <Icon
            prefix="far"
            name="bars-sort"
            size={24}
            color={newGrey[900]}
            onClick={handleClickBars}
          />
        </IconButton>
        <IconButton>
          <Icon prefix="far" name="search" size={24} color={newGrey[900]} />
        </IconButton>
        <IconButton>
          <Icon
            prefix="far"
            name="bell"
            size={24}
            color={newGrey[900]}
            badgeCount={3}
          />
        </IconButton>
      </Stack>
    </Stack>
  );
}
