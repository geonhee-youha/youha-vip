import _ from "lodash";
import { Backdrop, Box, ButtonBase, Stack } from "@mui/material";
import { pages } from "../../contants/pages";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";
import { useRouter } from "next/router";
import Button from "../atoms/Button";
import MainNavigationItem from "../molecules/MainNavigationItem";
import UserItem from "../molecules/UserItem";
import SearchBar from "../molecules/SearchBar";
import { useState } from "react";
import { useRecoilState } from "recoil";
import { mainDrawerOpenState } from "../../recoils";
import Visual from "../atoms/Visual";
import Typography from "../atoms/Typography";

const testUser = {
  thumbnail:
    // "data:images/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAeFBMVEUAAAD////IyMjo6Oi8vLyJiYm5ubn8/Pzw8PDMzMyBgYGcnJwbGxvU1NSoqKgEBAT29vbX19ff39+ysrIyMjKjo6Nra2s3NzcdHR0MDAxAQEDCwsIrKyteXl52dnaTk5NNTU2YmJhZWVl8fHxnZ2eNjY0mJiZFRUU5UntSAAAFHklEQVR4nO2a22KiMBRFQVQQRUDF+7VK/f8/HFAhOScgcUpoH/Z6mWkISRa5J1oWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAODPsFlnbH67FIb4uoycyH4QzUanLyXCJhT/D0Pl8cdIaYTWZKMm3EYmJefhS07gTbd51oKd7QpGP89zIKVnB+tnoCPlYQ9/nsmLQ5wrubLf44/eVo7Vk5+3YJhKye2Kj+nImfR/nsmDxYhXn2AuxWvbcCC+5rgMNGHok7rjOKsyojFD2xeBBgzn7/zyD1wOOaYMXXlQa9+QFLuac1XU9gyzViKNZ60bvumCJdHiGdeMYbyxTBo2NdEns2cZjBjuWGDLhlctwWKoM2E45oHtGn4rs3yd4z6PbmA+9JXAdg13tjpRuFHV5PGYFts3PKiBrRp+Mbes2Md8dTi5xor3JOuJnxrmffd7mexix5kFu+lyb9FV4PHOIrduyMfRSHxSpYMOrOo6/Lom8/78tPyuzOEYkAYRp5PGQrVpuGU16O2LJ9n3PDDDoMrw0BcdOT5atIayxZLHv5PtJtLccIyDkrhnwHDKcj+TAl5Y0TaK4TagUWZ3ksBCaeoPvGUZQ15525EBQ/aF5+yxQx/fmGGvYqZZSq8fale7SRFlIId67Rueab7unj0f0+cnZlgpcCvfPtb52eJbmjY80Wx79GnIv8BQXcKqklExkvBuTEm6MdzRXK9KhPWEoLVIf1XPvmEpsezEcEYzXTS/oWH4qkQ+D3msz3udGNJMo+YXdAztfM4gndC1R7d1VqsDkt+0A8M9LdmsJcO5UsrB6+213GjctXlDOt/zgea/DfOVwVIOSMvXN3LnPHVuqJMWNxzdVtsj684OiyfaRkhG75l5wzstmc7JJDN8be3oyiYr6EaeRVJpnbOQIy66rkO+1W42DCoT8lgjJesIufS+ccMVNQya3yCGbra3CyvK5LHFUCAjV+7UuOGarkgcvjFoMLS9MnqfFZQtJWoY/fn5UAwhCSsoG3tqcDpf06hXTWk6SAVXZiiaNWmVnrJnqcEzb8gOEi/8OTvjcGrPaf6sIdvfKYuahD6PtQ3ZxvL3DNmyTTn3YgXlu6d6wz/TD3lJWCXyLayvbShHi/w6bh0Y0i2wK04XckLem1bahnLzdt8drhk2DPmM+FwNF7BTpkcNaxqS2r8pGXdmaFVcy+yK29Aza8Fu1khrT4S54bduGc0bkpXw0yS4XJf+WD0HfOSvaWiR16WFaZhMS9JODLMe8/aCW8L/xNCXA2KRndxmki4MQ92pqyimriGd80evH8pshnLovgtDSzkzrcNdfGIY0qLbUXJYrG5TaYfvPg87ujCkDaqW11m2tiGdait6QrTJY3ViaF00BIuzJO1Waq0a+nc356Uv2NF3BeVZkr6hdXub4mvi7ciw8S5fXLd8YPj23qK4u+/K0Nq+WyrH4idRnxiG1rl2E1XeH3RlmHX5tO6aIUot6XTjkzrks4P4ZOLHgJ3VYc6pamb02E9ByG1EsccPlVOMkvvjkxSDzuPf2VF6XnlDSqpe5wRQi7yWDnN2cLNb8min/rCkL84EjnLwnCS6GMfSqOoN6R70Jr04LF6cyqkNrHbZHy/9YJbRmw7uzdH1CA+DpN/r9RO/tSRBA23+tNp8sgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8Bv8AMp9DmDVfcYoAAAAASUVORK5CYII=",
    "https://ca.slack-edge.com/T046G0T86-U03KY9VGXB9-c9720be2901a-512",
  email: "yeongyu.yu@youha.info",
  title: "유연규",
  position: "팀장",
  group: "제일기획",
};
export default function MainDrawer() {
  const router = useRouter();
  const currentPathName = `/${router.pathname.split("/")[1]}`;
  const show = _.findLast(pages, (el) => `${el.pathName}` === currentPathName);
  const [mainDrawerOpen, setMainDrawerOpen] =
    useRecoilState(mainDrawerOpenState);
  const handleBackdropClick = () => {
    setMainDrawerOpen(false);
  };
  return show ? (
    <>
      <Backdrop
        open={mainDrawerOpen}
        onClick={handleBackdropClick}
        sx={{
          transition: `all 0.35s ease`,
          display: "none",
          "@media(max-width: 578px)": {
            display: "flex",
            zIndex: 1000,
          },
        }}
      />
      <Stack
        sx={{
          position: "fixed",
          top: 0,
          bottom: 0,
          width: 320,
          backgroundColor: "#ffffff",
          p: theme.spacing(5.5, 0, 1.5, 0),
          zIndex: 10,
          overflow: "scroll",
          borderRight: `1px solid ${newGrey[200]}`,
          transition: `all 0.35s ease`,
          left: 0,
          "@media(max-width: 578px)": {
            left: mainDrawerOpen ? 0 : "-100%",
            zIndex: 1000,
            p: theme.spacing(0),
            borderRight: "none",
          },
        }}
      >
        <Header />
        <MainPages />
      </Stack>
    </>
  ) : null;
}

function Header() {
  const router = useRouter();
  const { thumbnail, title, email, group } = testUser;
  const handleClickUser = () => {
    router.push(`/mypage`);
  };
  return (
    <Stack
      spacing={1}
      sx={{
        p: theme.spacing(1.5, 0),
      }}
    >
      <ButtonBase
        sx={{
          p: theme.spacing(1, 2),
        }}
        onClick={handleClickUser}
      >
        <Stack
          direction="row"
          alignItems="center"
          spacing={1.5}
          sx={{ width: "100%" }}
        >
          <Visual src={thumbnail} size={62} borderRadius="50%" />
          <Stack spacing={0} sx={{ flex: 1 }}>
            <Typography variant="title-4" sx={{ fontWeight: "700" }}>
              {title}
            </Typography>
            <Typography variant="body-5" color={newGrey[500]}>
              {email}
            </Typography>
            <Stack direction="row" sx={{ m: theme.spacing(1, 0, 0, 0) }}>
              <Box
                sx={{
                  borderRadius: 2,
                  border: `1px solid ${newGrey[300]}`,
                  height: 20,
                  p: theme.spacing(0.25, 1),
                }}
              >
                <Typography variant="caption-2" color={newGrey[650]}>
                  {group}
                </Typography>
              </Box>
            </Stack>
          </Stack>
        </Stack>
      </ButtonBase>
      <Stack sx={{ p: theme.spacing(0, 2) }}>
        <Button fullWidth size="md" iconName="plus">
          바로 광고 집행하기
        </Button>
      </Stack>
    </Stack>
  );
}

function MainPages() {
  const mainPages = _.filter(pages, (el) => el.main === true);
  return (
    <Stack>
      {mainPages.map((item, index) => (
        <MainNavigationItem
          key={index}
          item={item}
          count={item.pathName === "/announces" ? 3 : 0}
        />
      ))}
    </Stack>
  );
}
