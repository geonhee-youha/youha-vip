import { Box, ButtonBase, Stack } from "@mui/material";
import { theme } from "../../themes/theme";
import Typography from "../atoms/Typography";
import dayjs from "dayjs";
import { AnnounceProps } from "../../types/announce";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import Icon from "../atoms/Icon";
import { newGrey } from "../../themes/colors";

export default function AnnounceItem({
  item,
  inDrawer,
}: {
  item: AnnounceProps;
  inDrawer?: boolean;
}) {
  const router = useRouter();
  const { id: queryId } = router.query;
  const { id, publishedAt, title, contents } = item;
  const [open, setOpen] = useState<boolean>(false);
  const [bodyHeight, setBodyHeight] = useState<number>(0);
  const checked = `${queryId}` === `${id}`;
  const titleColor = newGrey[900];
  const publishedAtColor = newGrey[500];
  useEffect(() => {
    if (!inDrawer) {
      if (checked) {
        const bodyEl: HTMLElement | null = document.querySelector(
          `.AnnounceItem-${id}-body`
        );
        setOpen(true);
        setBodyHeight(bodyEl ? bodyEl.offsetHeight : 0);
      } else {
        setOpen(false);
      }
    }
  }, [queryId]);
  const handleClick = () => {
    if (inDrawer) {
      router.push(`/announces?id=${id}`);
    } else {
      const bodyEl: HTMLElement | null = document.querySelector(
        `.AnnounceItem-${id}-body`
      );
      setOpen((prev) => !prev);
      setBodyHeight(bodyEl ? bodyEl.offsetHeight : 0);
    }
  };
  return (
    <Box
      sx={{
        width: "100%",
      }}
    >
      <ButtonBase
        sx={{
          width: "100%",
          p: theme.spacing(1, 2, 1, 2),
        }}
        onClick={handleClick}
      >
        <Stack direction="row" spacing={2} sx={{ width: "100%" }}>
          <Stack spacing={0.5} direction="row" sx={{ width: "100%" }}>
            <Typography
              variant="title-5"
              color={titleColor}
              sx={{ flex: 1, p: theme.spacing(0, 1, 0, 0) }}
            >
              {title}
            </Typography>
            <Typography variant="body-5" color={publishedAtColor}>
              {dayjs(publishedAt).format("MM월 DD일")}
            </Typography>
          </Stack>
          {!inDrawer && (
            <Icon
              prefix="fal"
              name="angle-down"
              sx={{
                ml: "auto",
                transform: `rotate(${open ? 180 : 0}deg)`,
                transition: `all 0.35s ease`,
              }}
            />
          )}
        </Stack>
      </ButtonBase>
      {!inDrawer && (
        <Box
          sx={{
            position: "relative",
            width: "100%",
            height: open ? bodyHeight + 12 : 0,
            transition: `all 0.35s ease`,
            overflow: "hidden",
          }}
        >
          <Box
            sx={{
              position: "absolute",
              top: 0,
              left: 0,
              pt: 1,
              pb: 0.5,
            }}
          >
            <Box
              sx={{
                p: theme.spacing(2),
                backgroundColor: newGrey[150],
                borderRadius: 1,
              }}
              className={!inDrawer ? `NoticeItem-${id}-body` : ""}
            >
              <Typography variant="body-2">{contents}</Typography>
            </Box>
          </Box>
        </Box>
      )}
    </Box>
  );
}
