import { Box, ButtonBase, Stack } from "@mui/material";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";
import Typography from "../atoms/Typography";
import Visual from "../atoms/Visual";

export default function UserItem({ item }: { item: any }) {
  const { thumbnail, title, email, group } = item;
  return (
    <ButtonBase
      sx={{
        p: theme.spacing(1, 2),
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        spacing={1.5}
        sx={{ width: "100%" }}
      >
        <Visual src={thumbnail} size={62} borderRadius="50%" />
        <Stack spacing={0} sx={{ flex: 1 }}>
          <Typography variant="title-4" sx={{ fontWeight: "700" }}>
            {title}
          </Typography>
          <Typography variant="body-5" color={newGrey[500]}>
            {email}
          </Typography>
          <Stack direction="row" sx={{ m: theme.spacing(1, 0, 0, 0) }}>
            <Box
              sx={{
                borderRadius: 2,
                border: `1px solid ${newGrey[300]}`,
                height: 20,
                p: theme.spacing(0.25, 1),
              }}
            >
              <Typography variant="caption-2" color={newGrey[650]}>
                {group}
              </Typography>
            </Box>
          </Stack>
        </Stack>
      </Stack>
    </ButtonBase>
  );
}
