import { Box, ButtonBase, Stack } from "@mui/material";
import { useRouter } from "next/router";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { PageProps, SlugProps } from "../../contants/pages";
import { newGrey, newRed } from "../../themes/colors";
import { theme } from "../../themes/theme";
import { youhaBlue } from "../../themes/youhaBlue";
import Icon from "../atoms/Icon";
import Typography from "../atoms/Typography";

export default function MainNavigationItem({
  item,
  count,
}: {
  item: PageProps;
  count?: number;
}) {
  const router = useRouter();
  const [open, setOpen] = useState<boolean>(false);
  const { title, iconName, pathName, slugs } = item;
  const currentPathName = `/${router.pathname.split("?")[0].split("/")[1]}`;
  const checked = currentPathName === pathName;
  const slugChecked = checked && !open;
  const prefix = "far";
  const color = slugChecked ? youhaBlue[500] : newGrey[900];
  const rightColor = slugChecked ? youhaBlue[500] : newRed[400];
  const rightIconColor = newGrey[400];
  const height = open && slugs ? slugs.length * 36 : 0;
  const handleClick = () => {
    if (slugs) return setOpen((prev) => !prev);
    router.push(pathName);
  };
  return (
    <Box
      sx={{
        width: "100%",
        transition: `all 0.35s ease`,
        p: theme.spacing(0, 0, open ? 1 : 0, 0),
      }}
    >
      <ButtonBase
        sx={{
          position: "relative",
          width: "100%",
          p: theme.spacing(1, 2),
        }}
        onClick={handleClick}
      >
        <Stack
          direction="row"
          alignItems="center"
          spacing={1}
          sx={{ width: "100%" }}
        >
          <Icon prefix={prefix} name={iconName} size={20} color={color} />
          <Typography
            variant="heading-3"
            color={color}
            sx={{
              flex: 1,
              "& span": {
                color: rightColor,
                m: theme.spacing(0, 0, 0, 0.5),
              },
            }}
          >
            {title}
            {count !== undefined && count > 0 && <span>{count}</span>}
          </Typography>
          {slugs && (
            <Icon
              prefix={prefix}
              name="angle-down"
              size={20}
              color={rightIconColor}
              sx={{
                ml: "auto",
                transform: `rotate(${open ? 180 : 0}deg)`,
                transition: `all 0.35s ease`,
              }}
            />
          )}
        </Stack>
      </ButtonBase>
      {slugs && (
        <Stack
          sx={{
            position: "relative",
            height: height,
            transition: `all 0.35s ease`,
            overflow: "hidden",
          }}
        >
          {slugs.map((item, index) => (
            <SlugItem
              key={index}
              item={item}
              pathName={pathName}
              setOpen={setOpen}
            />
          ))}
        </Stack>
      )}
    </Box>
  );
}
function SlugItem({
  item,
  pathName: parentPathName,
  setOpen,
  handleClickEstimate,
}: {
  item: SlugProps;
  pathName: string;
  setOpen?: Dispatch<SetStateAction<boolean>>;
  handleClickEstimate?: () => void;
}) {
  const router = useRouter();
  const { title, pathName } = item;
  const currentPathName = `/${router.pathname.split("?")[0].split("/")[2]}`;
  const slugChecked = currentPathName === pathName;
  const handleClick = () => {
    if (title === "견적내기") {
      if (handleClickEstimate !== undefined) handleClickEstimate();
      return;
    }
    router.push(`${parentPathName}${pathName}`);
  };
  useEffect(() => {
    if (slugChecked) {
      setOpen && setOpen(true);
    }
  }, [slugChecked]);
  const color = slugChecked ? youhaBlue[500] : newGrey[500];
  return (
    <ButtonBase
      sx={{
        width: "100%",
        p: theme.spacing(1, 2, 1, 5.5),
      }}
      onClick={handleClick}
    >
      <Typography variant="title-5" color={color}>
        {title}
      </Typography>
    </ButtonBase>
  );
}
