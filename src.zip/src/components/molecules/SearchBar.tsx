import { Stack } from "@mui/material";
import { newGrey } from "../../themes/colors";
import { theme } from "../../themes/theme";
import Icon from "../atoms/Icon";
import Typography from "../atoms/Typography";

export default function SearchBar() {
  return (
    <Stack
      direction="row"
      alignItems="center"
      spacing={0.5}
      sx={{
        height: 38,
        borderRadius: 0.5,
        backgroundColor: newGrey[150],
        p: theme.spacing(0, 1.5),
      }}
    >
      <Icon name="search" size={16} color={newGrey[400]} />
      <Typography variant="heading-4" color={newGrey[400]}>
        검색
      </Typography>
    </Stack>
  );
}
