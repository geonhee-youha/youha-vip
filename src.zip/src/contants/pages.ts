import { IconName } from "@fortawesome/fontawesome-svg-core";
export type SlugProps = {
    title: string;
    iconName: IconName;
    pathName: string;
}
export type PageProps = {
    title: string;
    iconName: IconName;
    pathName: string;
    slugs?: SlugProps[];
    main?: boolean;
}
export const pages: PageProps[] = [
    {
        title: '내 캠페인',
        iconName: 'grid-2',
        pathName: '/campaigns',
        main: true
    },
    {
        title: '광고집행 관리',
        iconName: 'rectangle-ad',
        pathName: '/commercials',
        slugs: [
            {
                iconName: 'file-invoice-dollar',
                title: '견적서 관리',
                pathName: '/estimates'
            },
            {
                iconName: 'users-rectangle',
                title: '광고세트 관리',
                pathName: '/sets'
            },
        ],
        main: true
    },
    {
        title: '인사이트',
        iconName: 'lightbulb-exclamation',
        pathName: '/insights',
        slugs: [
            {
                iconName: 'users',
                title: '추천 크리에이터',
                pathName: '/creators'
            },
            {
                iconName: 'files',
                title: '추천 기획안',
                pathName: '/projects'
            },
            {
                iconName: 'grid-2',
                title: '추천 광고영상',
                pathName: '/videos'
            },
        ],
        main: true
    },
    {
        title: '크리에이터 리스트',
        iconName: 'address-book',
        pathName: '/creators',
        main: true
    },
    {
        title: '즐겨찾기',
        iconName: 'star',
        pathName: '/favorites',
        main: true
    },
    {
        title: '공지사항',
        iconName: 'bullhorn',
        pathName: '/announces',
        main: true
    },
    {
        title: '마이페이지',
        iconName: 'user',
        pathName: '/mypage',
    },
]