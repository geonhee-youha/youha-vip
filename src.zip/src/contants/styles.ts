import { SxProps } from "@mui/material";
import { theme } from "../themes/theme";
export type TypographyVariantProps =
  | "heading-1"
  | "heading-2"
  | "heading-3"
  | "heading-4"
  | "title-1"
  | "title-2"
  | "title-3"
  | "title-4"
  | "title-5"
  | "body-1"
  | "body-2"
  | "body-3"
  | "body-4"
  | "body-5"
  | "caption-2"
export type ButtonVariantProps = "contained" | "outlined" | "text" | undefined;
export type ButtonSizeProps = "sm" | "md" | "lg" | 'xl';
export type FontStyleProps = {
  fontSize: number;
  lineHeight?: string;
  fontWeight?: string;
}

export const fontStyles: {
  [key: string]: FontStyleProps
} = {
  "heading-1": {
    fontSize: 24,
    lineHeight: `28px`,
    fontWeight: '900'
  },
  "heading-2": {
    fontSize: 17,
    lineHeight: `24px`,
    fontWeight: '700'
  },
  "heading-3": {
    fontSize: 14,
    lineHeight: `20px`,
    fontWeight: '700'
  },
  "heading-4": {
    fontSize: 13,
    lineHeight: `16px`,
    fontWeight: '500'
  },
  "title-1": {
    fontSize: 23,
    lineHeight: `30px`,
    fontWeight: '700'
  },
  "title-2": {
    fontSize: 19,
    lineHeight: `28px`,
    fontWeight: '600'
  },
  "title-3": {
    fontSize: 16,
    lineHeight: `24px`,
    fontWeight: '500'
  },
  "title-4": {
    fontSize: 15,
    lineHeight: `20px`,
    fontWeight: '500'
  },
  "title-5": {
    fontSize: 14,
    lineHeight: `20px`,
    fontWeight: '500'
  },
  "body-1": {
    fontSize: 16,
    lineHeight: `28px`,
    fontWeight: '400'
  },
  "body-2": {
    fontSize: 14,
    lineHeight: `24px`,
    fontWeight: '400'
  },
  "body-3": {
    fontSize: 13,
    lineHeight: `20px`,
    fontWeight: '400'
  },
  "body-4": {
    fontSize: 12,
    lineHeight: `18px`,
    fontWeight: '400'
  },
  "body-5": {
    fontSize: 11,
    lineHeight: `14px`,
    fontWeight: '400'
  },
  "caption-2": {
    fontSize: 10,
    lineHeight: `14px`,
    fontWeight: '500'
  },
};
export const buttonSizes: {
  [key: string]: SxProps;
} = {
  sm: {
    height: 'auto !important',
    minHeight: `${30}px !important`,
    alignItems: 'center',
    p: `${theme.spacing(0, 1.5)} !important`,
  },
  md: {
    height: 'auto !important',
    minHeight: `${38}px !important`,
    alignItems: 'center',
    p: `${theme.spacing(0, 2)} !important`,
  },
  lg: {
    height: 'auto !important',
    minHeight: `${44}px !important`,
    alignItems: 'center',
    p: `${theme.spacing(0, 2.25)} !important`,
  },
  xl: {
    height: 'auto !important',
    minHeight: `${48}px !important`,
    alignItems: 'center',
    p: `${theme.spacing(0, 2.25)} !important`,
  },
};
export const buttonFontStyles: {
  [key: string]: FontStyleProps
} = {
  sm: {
    fontSize: 12,
    lineHeight: `18px`,
    fontWeight: '600'
  },
  md: {
    fontSize: 13,
    lineHeight: `20px`,
    fontWeight: '600'
  },
  lg: {
    fontSize: 15,
    lineHeight: `24px`,
    fontWeight: '600'
  },
  xl: {
    fontSize: 15,
    lineHeight: `24px`,
    fontWeight: '700'
  },
}
export const buttonIconSizes: {
  [key: string]: FontStyleProps
} = {
  sm: {
    fontSize: 15,
    lineHeight: `24px`,
    fontWeight: '600'
  },
  md: {
    fontSize: 13,
  },
  lg: {
    fontSize: 15,
    lineHeight: `24px`,
    fontWeight: '600'
  },
  xl: {
    fontSize: 15,
    lineHeight: `24px`,
    fontWeight: '600'
  },
}