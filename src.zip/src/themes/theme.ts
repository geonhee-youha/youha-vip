import { newGrey } from './colors';
import { alpha } from "@mui/material";
import { createTheme } from "@mui/material/styles";
import {
  red,
  purple,
  blue,
  indigo,
  grey
} from "@mui/material/colors";
import { youhaBlue } from "./youhaBlue";
export const primaryColor = youhaBlue
export const theme = createTheme({
  palette: {
    mode: "light",
    primary: primaryColor,
    secondary: purple,
    grey: grey,
    error: red,
    common: {
      black: grey[900],
    },
    action: {
      active: alpha(grey[900], 0.54),
      hover: alpha(grey[900], 0.04),
      selected: alpha(grey[900], 0.08),
      disabled: alpha(grey[900], 0.26),
      disabledBackground: alpha(grey[900], 0.12),
      focus: alpha(grey[900], 0.12),
    },
  },
  shape: {
    borderRadius: 8,
  },
  typography: {
    h1: {
      fontSize: 33,
      lineHeight: "40px",
      fontWeight: "700",
    },
  },
  components: {
    // MuiInputLabel: {
    //   styleOverrides: {
    //     root: {
    //       fontWeight: 500,
    //     },
    //   },
    // },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          // color: grey[300],
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          fontSize: 16,
          lineHeight: '24px',
          "& *": { borderWidth: `1px !important` },
          "& fieldset": {
            borderWidth: 1,
            borderColor: youhaBlue[100],
          },
          "&:hover fieldset": {
            borderWidth: 1,
            borderColor: youhaBlue[500],
          },
          "&.Mui-focused fieldset": {
            borderWidth: 1,
            borderColor: youhaBlue[500],
          },
        },
      },
    },
    MuiTypography: {
      styleOverrides: {
        root: {
          fontFamily: `Pretendard, -apple-system, BlinkMacSystemFont, system- ui, Roboto, "Helvetica Neue", "Segoe UI", "Apple SD Gothic Neo","Noto Sans KR", "Malgun Gothic", sans- serif`,
          color: grey[900],
        },
      },
    },
    MuiButtonBase: {
      styleOverrides: {
        root: {
          borderRadius: 0,
          justifyContent: 'flex-start',
          alignItems: 'flex-start',
          textAlign: "left",
          cursor: 'pointer !important',
          position: 'relative',
          ':before': {
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            content: '""',
            backgroundColor: 'transparent',
            transition: `all 0.35s ease`,
          },
          ":hover:before": {
            backgroundColor: `rgba(0, 0, 0, 0.12)`
          },
          '& *': {
            cursor: 'pointer !important',
          },
          transition: `all 0.35s ease`,
        },
      },
    },
    MuiContainer: {
      defaultProps: {
        maxWidth: false,
      },
      styleOverrides: {
        root: {
          maxWidth: 1440,
          // paddingLeft: "16px !important",
          // paddingRight: "16px !important",
          // paddingLeft: "24px !important",
          // paddingRight: "24px !important",
          "@media(min-width: 1440px)": {
            paddingLeft: "80px",
            paddingRight: "80px",
          },
        },
      },
    },
    MuiList: {
      styleOverrides: {
        root: {
          maxWidth: 1000,
          marginLeft: "auto",
          marginRight: "auto",
        },
      },
    },
    MuiListItem: {
      styleOverrides: {
        root: {
          maxWidth: 1000,
          paddingLeft: "16px",
          paddingRight: "16px",
          marginLeft: "auto",
          marginRight: "auto",
        },
      },
    },
    MuiListItemButton: {
      defaultProps: {
        disableRipple: true,
        disableTouchRipple: true,
      },
      styleOverrides: {
        root: {
          maxWidth: 1000,
          paddingLeft: "16px",
          paddingRight: "16px",
          marginLeft: "auto",
          marginRight: "auto",
          "&:hover": {
            backgroundColor: "transparent",
          },
          "&:focus": {
            backgroundColor: "transparent",
          },
        },
      },
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          maxWidth: 1000,
          marginLeft: "auto",
          marginRight: "auto",
        },
      },
    },
    MuiBackdrop: {
      styleOverrides: {
        root: {
          backgroundColor: "rgba(0, 0, 0, 0.8)",
        },
      },
    },
    MuiIcon: {
      styleOverrides: {
        root: {
          width: "auto",
          height: "auto",
          fontSize: "1.25rem",
          padding: ".25rem",
        },
        fontSizeSmall: {
          fontSize: "1rem",
        },
        fontSizeLarge: {
          fontSize: "1.75rem",
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: "transparent",
          color: grey[900],
        },
      },
    },
    MuiToolbar: {
      styleOverrides: {
        root: {
          minHeight: 56,
          paddingLeft: "16px",
          paddingRight: "16px",
        },
      },
    },
    MuiBottomNavigation: {
      styleOverrides: {
        root: {
          height: 56,
        },
      },
    },
    MuiPopover: {
      styleOverrides: {
        root: {
          zIndex: 999999
        }
      }
    },
    MuiButton: {
      defaultProps: {
        disableElevation: false,
        variant: "contained",
        size: "large",
      },
      styleOverrides: {
        root: {
          letterSpacing: "-0.4px",
          whiteSpace: "nowrap",
          textTransform: "none",
          padding: 0,
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          color: grey[700],
        },
        sizeSmall: {
          fontSize: 12,
        },
        sizeMedium: {
          fontSize: 14,
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          width: 28,
          height: 28,
          borderRadius: 8,
          border: `1px solid ${grey[300]}`,
          backgroundColor: '#ffffff',
          padding: 0,
          cursor: 'pointer',
          '& *': {
            cursor: 'pointer',
          },
          "&:hover": {
            backgroundColor: newGrey[150],
          },
          "&:focus": {
            backgroundColor: '#ffffff',
          },
          '& span': {
            borderRadius: 8,
          }
        },
      },
    },
    MuiInputBase: {
      styleOverrides: {
        root: {
          font: 'initial !important',
          fontSize: 16,
          lineHeight: '24px',
          '& input': {
            font: 'initial !important',
            fontSize: 16,
            lineHeight: '24px !important',
            padding: 0,
            height: 'auto',
          }
        }
      }
    }
  },
});
